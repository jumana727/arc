﻿
namespace VPM.Application.Models
{

    public class StremMapping
    {

        public int PipeLineId { get; set; }

        public string RtspUrl { get; set; } = string.Empty;

        public string WebRtcUrl { get; set; } = string.Empty;

    }

}