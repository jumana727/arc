namespace PushNotifications.Models;

public record UserAndTokens(string FcmToken, string UserId);
